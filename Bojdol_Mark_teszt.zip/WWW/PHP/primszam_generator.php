<?php

// böngészőben futtatva hibát ír ki mivel
// a C# alkalmazás adja át a post tombnek az értékeket.


//megvizsgálom a $_POST tömb tartalmazza-e a szükséges indexű változókat
//ha igen akkor felhasználjuk az értékeket
if(isset($_POST["min"])&& isset($_POST["max"]));
{
	$min=$_POST["min"];
	$max=$_POST["max"];
}

	$i=0;
	$generated = 0;
	$prime=false;
	
// addig fut a ciklus ameddig nem talál prím számot
// az adott intervallumban 
// generálok egy random számot a min és max értékek között
// kezdetbenfeltételezem hogy prím, for ciklussal ellenőrzöm
// elég csak a szám feléig keresnem az osztót.
// 
while($prime!=true)
{
	$prime=true;
	$generated = rand($min,$max);

	for($i = 2; $i<=$generated/2; $i++)
	{
			if($generated%$i==0)
			{
				$prime=false;		
			}
	}
		if($prime==true)
		{
			$prime_number=$generated;
			echo($prime_number);
	
		}
}
?>