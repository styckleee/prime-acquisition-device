<?php

if(isset($_POST["min"])&& isset($_POST["max"]));
{
	$min=$_POST["min"];
	$max=$_POST["max"];
}

	$i=0;
	$generated = 0;
	$prime=false;
	
while($prime!=true)
{
	$prime=true;
	$generated = rand($min,$max);

	for($i = 2; $i<=$generated/2; $i++)
	{
			if($generated%$i==0)
			{
				$prime=false;		
			}
	}
		if($prime==true)
		{
			$prime_number=$generated;
			echo($prime_number);
	
		}
}
?>